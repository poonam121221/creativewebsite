<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');  
 
require_once APPPATH."/third_party/excel-library/php-excel-reader/excel_reader2.php";
require_once APPPATH."/third_party/excel-library/SpreadsheetReader.php";
//require_once APPPATH."/third_party/PHPExcel.php";
//require_once APPPATH."/third_party/PHPExcel/IOFactory.php";

class Excel {
    //public function __construct() {
        //parent::__construct();
    //}
}//end Excel class