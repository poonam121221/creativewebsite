<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class DashboardModel extends MY_Model {

	public function __construct(){
		parent::__construct();
	}//end constructor
	
	function index(){
		
	}
	
}//end class